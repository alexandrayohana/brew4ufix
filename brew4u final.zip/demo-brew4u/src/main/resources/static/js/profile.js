// Simpan nilai asli untuk fitur "Batal"
let originalData = {};

document.addEventListener('DOMContentLoaded', () => {
    // Simpan data awal saat halaman dimuat
    const inputs = document.querySelectorAll('#profileForm input');
    inputs.forEach(input => {
        originalData[input.name] = input.value;
    });
});

function toggleEditMode() {
    const inputs = document.querySelectorAll('#profileForm input:not([name="email"])'); // Email biasanya tidak boleh diedit (primary key/login ID)
    const btnEdit = document.getElementById('btnEdit');
    const btnSave = document.getElementById('btnSave');
    const btnCancel = document.getElementById('btnCancel');

    // 1. Aktifkan input
    inputs.forEach(input => {
        input.removeAttribute('readonly');
        input.style.color = '#000'; // Visual feedback
        input.parentElement.style.backgroundColor = '#FFF';
        input.parentElement.style.borderColor = '#C57E57'; // Primary color border
    });

    // Fokus ke input nama
    document.getElementById('inputNama').focus();

    // 2. Toggle Tombol
    btnEdit.style.display = 'none';
    btnSave.style.display = 'flex'; // Tampilkan tombol simpan
    btnCancel.style.display = 'flex'; // Tampilkan tombol batal
}

function cancelEdit() {
    const inputs = document.querySelectorAll('#profileForm input');
    const btnEdit = document.getElementById('btnEdit');
    const btnSave = document.getElementById('btnSave');
    const btnCancel = document.getElementById('btnCancel');

    // 1. Kembalikan nilai asli
    inputs.forEach(input => {
        input.value = originalData[input.name];
        input.setAttribute('readonly', true);
        input.style.color = ''; // Reset style
        input.parentElement.style.backgroundColor = '';
        input.parentElement.style.borderColor = '';
    });

    // 2. Toggle Tombol kembali
    btnEdit.style.display = 'flex';
    btnSave.style.display = 'none';
    btnCancel.style.display = 'none';
}

// Opsional: Notifikasi sederhana jika form disubmit
// (Jika Anda menggunakan form submit standar, browser akan reload, jadi ini hanya kosmetik sebelum reload)
document.getElementById('profileForm').addEventListener('submit', function(e) {
    // Validasi sederhana
    const nama = document.getElementById('inputNama').value;
    if (nama.trim() === "") {
        e.preventDefault();
        showNotification("Nama tidak boleh kosong!", "error");
    }
});

function showNotification(text, type) {
    const messageBox = document.getElementById('messageBox');
    messageBox.textContent = text;
    messageBox.classList.add('visible');

    messageBox.style.backgroundColor = (type === 'error') ? '#dc3545' : '#333';

    setTimeout(() => {
        messageBox.classList.remove('visible');
    }, 2000);
}