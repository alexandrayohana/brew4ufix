const modal = document.getElementById("menuModal");
const form = document.querySelector(".menu-form");
const modalTitle = document.getElementById("modalTitle");

// 1. FUNGSI BUKA MODAL TAMBAH
function openAddModal() {
    form.reset();
    document.getElementById("mId").value = "";

    // Pastikan checkbox rekomendasi unchecked saat tambah baru
    const cbRekomen = document.getElementById("mRekomen");
    if (cbRekomen) cbRekomen.checked = false;

    modalTitle.innerText = "Tambah Menu Baru";
    modal.style.display = "flex";
}

// 2. FUNGSI BUKA MODAL EDIT
function openEditModal(id) {
    // Panggil API Backend
    fetch('/admin/api/menu/' + id)
        .then(res => {
            if (!res.ok) throw new Error("Gagal mengambil data");
            return res.json();
        })
        .then(data => {
            // Isi Form dengan data lama
            document.getElementById("mId").value = data.kode_menu;
            document.getElementById("mNama").value = data.nama_menu;
            document.getElementById("mHarga").value = data.harga;
            document.getElementById("mStok").value = data.stok;
            document.getElementById("mGambar").value = data.gambar;
            document.getElementById("mDeskripsi").value = data.deskripsi;

            // --- LOGIC CENTANG CHECKBOX REKOMENDASI ---
            const cbRekomen = document.getElementById("mRekomen");
            if (cbRekomen) {
                // Jika isRecommended == true, centang box. Jika false/null, jangan centang.
                cbRekomen.checked = data.isRecommended === true;
            }
            // ------------------------------------------

            modalTitle.innerText = "Edit Menu";
            modal.style.display = "flex";
        })
        .catch(err => {
            console.error(err);
            alert("Gagal memuat data menu.");
        });
}

// 3. FUNGSI TUTUP MODAL
function closeModal() {
    modal.style.display = "none";
}

// Tutup jika klik di luar modal box
window.onclick = function(e) {
    if (e.target == modal) closeModal();
}