// Fungsi Helper Format Rupiah
function formatRupiah(angka) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
}

// Fungsi Buka Modal
function openDetail(id) {
    const modal = document.getElementById("detailModal");
    const tbody = document.getElementById("mItemListBody");

    // Tampilan Loading
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center">Memuat data...</td></tr>';
    document.getElementById("mNama").innerText = "...";
    document.getElementById("mMeja").innerText = "...";
    document.getElementById("mTotal").innerText = "...";

    modal.style.display = "flex";

    fetch('/admin/api/pesanan/' + id)
        .then(response => {
            if (!response.ok) throw new Error("Gagal mengambil data");
            return response.json();
        })
        .then(paketData => {
            // SEKARANG DATA KITA PUNYA 2 BAGIAN: .header DAN .items

            // 1. ISI INFO HEADER (Pelanggan & Meja)
            const p = paketData.header;
            if (p) {
                const namaPelanggan = p.pelanggan ? p.pelanggan.nama_pelanggan : "Guest / Terhapus";
                document.getElementById("mNama").innerText = namaPelanggan;
                document.getElementById("mMeja").innerText = p.no_meja;
                document.getElementById("mTotal").innerText = formatRupiah(p.total_harga);

                // Form Update Status
                document.getElementById("mId").value = p.kode_pesanan;
                document.getElementById("mStatus").value = p.status;
            }

            // 2. ISI LIST MENU (Ambil dari .items)
            const listMenu = paketData.items;

            if (listMenu && listMenu.length > 0) {
                let htmlContent = '';
                listMenu.forEach(item => {
                    const namaMenu = item.menu ? item.menu.nama_menu : "Menu dihapus";
                    htmlContent += `
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 8px 0;">${namaMenu}</td>
                            <td style="padding: 8px 0;">x${item.quantity}</td>
                            <td style="padding: 8px 0; text-align:right;">${formatRupiah(item.subtotal)}</td>
                        </tr>
                    `;
                });
                tbody.innerHTML = htmlContent;
            } else {
                tbody.innerHTML = '<tr><td colspan="3" style="text-align:center">Tidak ada detail menu (Data Kosong)</td></tr>';
            }
        })
        .catch(error => {
            console.error("Error:", error);
            tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; color:red">Gagal memuat data</td></tr>';
        });
}

// Fungsi Tutup Modal
function closeModal() {
    document.getElementById("detailModal").style.display = "none";
}

// Klik di luar modal untuk menutup
window.onclick = function(event) {
    const modal = document.getElementById("detailModal");
    if (event.target === modal) {
        closeModal();
    }
}