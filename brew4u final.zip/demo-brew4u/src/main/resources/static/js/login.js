document.getElementById("loginForm").addEventListener("submit", async function(event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const errorBox = document.getElementById("errorMessage");

    errorBox.innerText = "";

    if (email === "" || password === "") {
        errorBox.innerText = "Email dan password tidak boleh kosong!";
        return;
    }

    try {
        const response = await fetch("http://localhost:8080/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: email, password: password })
        });

        if (response.ok) {
            window.location.href = "dashboard.html";
        } else {
            errorBox.innerText = "Login gagal! Periksa email atau password.";
        }
    } catch (error) {
        errorBox.innerText = "Terjadi kesalahan server!";
        console.log(error);
    }
});