let products = [];
let activeTab = 'all';

document.addEventListener('DOMContentLoaded', () => {

    // 1. Inisialisasi Data Produk dari DOM
    document.querySelectorAll('.coffee-card').forEach(card => {
        products.push({
            name: card.getAttribute('data-name'),
            category: card.getAttribute('data-category'), // Mengambil 'recommended' atau 'regular'
            element: card
        });
    });

    // 2. Listener Tab Klik
    document.querySelectorAll('.tab-button').forEach(button => {
        button.addEventListener('click', function() {
            // Ubah tampilan tombol aktif
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
                btn.classList.add('inactive');
            });
            this.classList.add('active');
            this.classList.remove('inactive');

            // Set tab aktif & filter
            activeTab = this.getAttribute('data-tab');
            filterProducts();
        });
    });

    // 3. Listener Search
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', filterProducts);
    }

    // 4. Jalankan filter awal
    filterProducts();

    // --- SETUP TOMBOL ADD & QTY (Logic Cart) ---
    setupCartButtons();
});

// FUNGSI FILTER UTAMA (Sesuai request Anda)
function filterProducts() {
    const searchInput = document.getElementById('searchInput');
    const searchTerm = searchInput ? searchInput.value.toLowerCase().trim() : "";

    products.forEach(product => {
        // Ambil kategori asli dari elemen
        const category = product.category;

        // Cek Nama (Search)
        const isNameMatch = product.name.toLowerCase().includes(searchTerm);

        // Cek Kategori (Tab)
        let isCategoryMatch = false;

        if (activeTab === 'all') {
            // Jika Tab 'Semua', tampilkan APAPUN (baik regular maupun recommended)
            isCategoryMatch = true;
        } else if (activeTab === 'recommended') {
            // Jika Tab 'Rekomendasi', HANYA tampilkan yang datanya 'recommended'
            isCategoryMatch = (category === 'recommended');
        }

        // Terapkan Filter
        if (product.element) {
            if (isNameMatch && isCategoryMatch) {
                product.element.style.display = ""; // Munculkan
            } else {
                product.element.style.display = "none"; // Sembunyikan
            }
        }
    });
}

// --- LOGIC CART (Sama seperti sebelumnya) ---

function setupCartButtons() {
    // Tombol Add (+) Awal
    document.querySelectorAll('.add-button').forEach(button => {
        button.addEventListener('click', () => {
            const kodeMenu = button.getAttribute('data-menu-id');
            const itemName = button.getAttribute('data-menu-name');
            sendCartUpdate(kodeMenu, 1, itemName);
        });
    });

    // Tombol Plus (+) di qty control
    document.querySelectorAll('.quantity-menu-control .qty-plus').forEach(button => {
        button.addEventListener('click', () => {
            const kodeMenu = button.getAttribute('data-menu-id');
            sendCartUpdate(kodeMenu, 1, null);
        });
    });

    // Tombol Minus (-) di qty control
    document.querySelectorAll('.quantity-menu-control .qty-minus').forEach(button => {
        button.addEventListener('click', () => {
            const kodeMenu = button.getAttribute('data-menu-id');
            sendCartUpdate(kodeMenu, -1, null);
        });
    });
}

function sendCartUpdate(kodeMenu, delta, itemName) {
    fetch('/cart/update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `kodeMenu=${kodeMenu}&delta=${delta}`
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response not ok');
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                // Update UI Angka
                const qtySpan = document.getElementById(`qty-${kodeMenu}`);
                let currentQuantity = parseInt(qtySpan.textContent) || 0;
                let newQuantity = currentQuantity + delta;

                toggleMenuControls(kodeMenu, newQuantity);

                if (delta > 0 && itemName) {
                    showNotification(`${itemName} berhasil ditambahkan!`, 'success');
                }
            } else {
                showNotification(data.message || 'Gagal update keranjang.', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Gagal koneksi server.', 'error');
        });
}

function toggleMenuControls(kodeMenu, quantity) {
    const controlGroup = document.getElementById(`control-${kodeMenu}`);
    const addButton = document.getElementById(`add-btn-${kodeMenu}`);
    const qtySpan = document.getElementById(`qty-${kodeMenu}`);

    if (quantity > 0) {
        addButton.style.display = 'none';
        controlGroup.style.display = 'flex';
        qtySpan.textContent = quantity;
    } else {
        addButton.style.display = 'flex';
        controlGroup.style.display = 'none';
    }
}

function showNotification(text, type) {
    const messageBox = document.getElementById('messageBox');
    if (!messageBox) return;

    messageBox.textContent = text;
    messageBox.className = 'visible'; // Reset class
    if (type === 'error') messageBox.style.backgroundColor = '#dc3545';
    else messageBox.style.backgroundColor = '#333';

    setTimeout(() => {
        messageBox.className = '';
    }, 2000);
}