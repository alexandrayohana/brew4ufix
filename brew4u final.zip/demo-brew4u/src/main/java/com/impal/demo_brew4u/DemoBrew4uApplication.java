package com.impal.demo_brew4u;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBrew4uApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoBrew4uApplication.class, args);
	}

}
